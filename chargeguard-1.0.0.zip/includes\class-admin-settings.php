<?php
class ChargeGuard_Admin_Settings {
    public function __construct() {
        add_action('admin_menu', [$this, 'add_admin_menu']);
        add_action('admin_init', [$this, 'register_settings']);
    }
    public function add_admin_menu() {
        add_submenu_page(
            'woocommerce',
            'ChargeGuard',
            'ChargeGuard',
            'manage_woocommerce',
            'chargeguard-settings',
            [$this, 'settings_page']
        );
    }
    public function register_settings() {
        register_setting('chargeguard_settings', 'chargeguard_api_key', 'sanitize_text_field');
        register_setting('chargeguard_settings', 'chargeguard_merchant_id', 'sanitize_text_field');
        register_setting('chargeguard_settings', 'chargeguard_webhook_secret', 'sanitize_text_field');
        register_setting('chargeguard_settings', 'chargeguard_stripe_webhook_secret', 'sanitize_text_field');
        register_setting('chargeguard_settings', 'chargeguard_enable_firewall', 'intval');
        register_setting('chargeguard_settings', 'chargeguard_firewall_block_duration', 'intval');
    }
    public function settings_page() {
        ?>
        <div class="wrap">
            <h1>ChargeGuard Settings</h1>
            <form method="post" action="options.php">
                <?php settings_fields('chargeguard_settings'); ?>
                <table class="form-table">
                    <tr>
                        <th scope="row">API Key</th>
                        <td><input type="text" name="chargeguard_api_key" value="<?php echo esc_attr(get_option('chargeguard_api_key')); ?>" class="regular-text" /></td>
                    </tr>
                    <tr>
                        <th scope="row">Merchant ID</th>
                        <td><input type="text" name="chargeguard_merchant_id" value="<?php echo esc_attr(get_option('chargeguard_merchant_id')); ?>" class="regular-text" /></td>
                    </tr>
                    <tr>
                        <th scope="row">Webhook Secret</th>
                        <td><input type="password" name="chargeguard_webhook_secret" value="<?php echo esc_attr(get_option('chargeguard_webhook_secret')); ?>" class="regular-text" /></td>
                    </tr>
                    <tr>
                        <th scope="row">Stripe Webhook Signing Secret</th>
                        <td><input type="password" name="chargeguard_stripe_webhook_secret" value="<?php echo esc_attr(get_option('chargeguard_stripe_webhook_secret')); ?>" class="regular-text" /></td>
                    </tr>
                </table>
                <h2>Dynamic Firewall</h2>
                <table class="form-table">
                    <tr>
                        <th scope="row">Enable Firewall</th>
                        <td><input type="checkbox" name="chargeguard_enable_firewall" value="1" <?php checked(1, get_option('chargeguard_enable_firewall', 1)); ?> /> Prevent blocked devices from accessing the checkout page</td>
                    </tr>
                    <tr>
                        <th scope="row">Block Duration (hours)</th>
                        <td><input type="number" name="chargeguard_firewall_block_duration" value="<?php echo esc_attr(get_option('chargeguard_firewall_block_duration', 24)); ?>" class="small-text" /> Hours before a blocked device is automatically unblocked</td>
                    </tr>
                </table>
                <?php submit_button(); ?>
            </form>
        </div>
        <?php
    }
}
